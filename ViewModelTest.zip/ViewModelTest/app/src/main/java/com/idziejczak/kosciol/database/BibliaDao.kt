package com.idziejczak.kosciol.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface BibliaDao {
    @Query("SELECT * FROM biblia")
    fun getAll(): LiveData<List<Biblia>>

    @Query("SELECT * FROM biblia WHERE ksiega = :ksiega")
    fun getPoKsiedze(ksiega: String): LiveData<List<Biblia>>

    @Query("SELECT ksiega FROM biblia")
    fun getKsiegi(): LiveData<List<String>>

    @Insert
    suspend fun inser(biblia: Biblia)

    @Query("DELETE FROM biblia")
    suspend fun deleteAll()

    @Query("DELETE FROM biblia WHERE rozdzial = 'home'")
    suspend fun deleteHome()
}