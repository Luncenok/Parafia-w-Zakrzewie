package com.idziejczak.kosciol.ui.wybor

import android.os.Bundle
import android.text.Html
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.idziejczak.kosciol.R
import kotlinx.android.synthetic.main.wybor_fragment.*

class WyborFragment : Fragment() {

    companion object {
        fun newInstance() = WyborFragment()
    }

    private lateinit var viewModel: WyborViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val root: View = inflater.inflate(R.layout.wybor_fragment, container, false)
        viewModel = ViewModelProviders.of(this).get(WyborViewModel::class.java)


        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(WyborViewModel::class.java)
        // TOD: Use the ViewModel

        val kategoria = activity?.intent?.getStringExtra("kategoria")
        var slesz = activity?.intent?.getStringExtra("slesz")
        if (slesz == null) {
            slesz = ""
        }
        val spanstr = viewModel.dwnldcontent(slesz)


        messag.text = spanstr

//        when (kategoria) {
//            "" -> messag.text = "jest nullem"
//            else -> messag.text = "błędzik w when"
//        }
    }

}
