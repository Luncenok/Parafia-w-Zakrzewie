package com.idziejczak.kosciol.ui.main

import android.os.Bundle
import android.os.StrictMode
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.idziejczak.kosciol.R
import com.idziejczak.kosciol.database.Biblia
import timber.log.Timber

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    private var mLiksiegi = ArrayList<Biblia>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        Timber.e("OnCreateView created")
        val root = inflater.inflate(R.layout.main_fragment, container, false)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        val recyclerView: RecyclerView = root.findViewById(R.id.recycler_view)
        val homeAdapter = context?.let { HomeAdapter(it) }
        recyclerView.adapter = homeAdapter
        recyclerView.layoutManager = LinearLayoutManager(context)

        viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)
        viewModel.allBiblia.observe(this, Observer { libiblia ->
            libiblia.let { homeAdapter?.setLiBiblia(it) }
        })
        viewModel.dwnldFromPage()//To do odświeżenia

        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        Timber.e("OnActivityCreated created")
        viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)
    }

    override fun onResume() {
        super.onResume()
        Timber.e("Siemanowice resumowice")
        viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)
        viewModel.dwnldFromPage()
    }


}
