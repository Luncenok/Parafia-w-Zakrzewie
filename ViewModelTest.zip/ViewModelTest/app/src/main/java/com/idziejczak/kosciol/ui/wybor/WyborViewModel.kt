package com.idziejczak.kosciol.ui.wybor

import android.app.Application
import android.text.Html
import android.text.SpannableStringBuilder
import android.text.Spanned
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.idziejczak.kosciol.database.AppDatabase
import com.idziejczak.kosciol.database.Biblia
import com.idziejczak.kosciol.database.BibliaRepository
import kotlinx.coroutines.launch
import org.jsoup.Jsoup

class WyborViewModel(application: Application) : AndroidViewModel(application) {
    // dzieje się
    private val repository: BibliaRepository
    val allBiblia: LiveData<List<Biblia>>
    var listaLinkow: ArrayList<String>
    var listaContentu: ArrayList<Spanned>

    init {
        val bibliaDao = AppDatabase.getDatabase(application, viewModelScope).bibliaDao()
        repository = BibliaRepository(bibliaDao)
        allBiblia = repository.allBiblia
        listaLinkow = ArrayList()
        listaContentu = ArrayList()
    }

    fun dwnldcontent(slesz: String): Spanned {
        val url = "https://kazimierz.archpoznan.pl"
        val doc = Jsoup.connect(url + slesz).get()

        delHome()
        doc.select(".content a:not(.page-link)").forEach { elem ->
            listaLinkow.add(elem.attr("href"))
        }
        listaLinkow.forEach { link ->
            val docum = Jsoup.connect(url + link).get()
            val content: Spanned = Html.fromHtml(
                docum.select(".content").toString()
                    .replace(
                        "« wstecz",
                        ""
                    ).replace(
                        "drukuj",
                        ""
                    ).replace(
                        "«",
                        ""
                    )
            )
            listaContentu.add(content)
        }
        val spanstr = SpannableStringBuilder()
        listaContentu.forEach {
            spanstr.append(it)
            spanstr.append("\n\n\n-----------------------\n\n\n")
        }
        return spanstr
    }

    fun inser(biblia: Biblia) = viewModelScope.launch {
        repository.inser(biblia)
    }

    fun delall() = viewModelScope.launch {
        repository.delall()
    }

    fun delHome() = viewModelScope.launch {
        repository.delHome()
    }
}
