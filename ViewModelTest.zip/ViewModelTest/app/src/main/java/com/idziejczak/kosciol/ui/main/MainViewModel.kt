package com.idziejczak.kosciol.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.idziejczak.kosciol.database.AppDatabase
import com.idziejczak.kosciol.database.Biblia
import com.idziejczak.kosciol.database.BibliaRepository
import kotlinx.coroutines.launch
import org.jsoup.Jsoup

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: BibliaRepository
    val allBiblia: LiveData<List<Biblia>>

    init {
        val bibliaDao = AppDatabase.getDatabase(application, viewModelScope).bibliaDao()
        repository = BibliaRepository(bibliaDao)
        allBiblia = repository.allBiblia
    }

    fun dwnldFromPage() {
        val url = "https://kazimierz.archpoznan.pl"
        val doc = Jsoup.connect(url).get()
        delHome()
        doc.select("ul.nav a").forEach { elem ->
            val biblia = Biblia(0, elem.text(), "home", elem.attr("href"))
            inser(biblia)
        }
    }

    fun inser(biblia: Biblia) = viewModelScope.launch {
        repository.inser(biblia)
    }

    fun delall() = viewModelScope.launch {
        repository.delall()
    }

    fun delHome() = viewModelScope.launch {
        repository.delHome()
    }

}
