package com.idziejczak.kosciol.database

import androidx.lifecycle.LiveData

class BibliaRepository(private val bibliaDao: BibliaDao) {
    val allBiblia: LiveData<List<Biblia>> = bibliaDao.getAll()
    val allksiegi: LiveData<List<String>> = bibliaDao.getKsiegi()

    suspend fun inser(biblia: Biblia) {
        bibliaDao.inser(biblia)
    }
    suspend fun delall() {
        bibliaDao.deleteAll()
    }
    suspend fun delHome() {
        bibliaDao.deleteHome()
    }
}